﻿namespace DotNet9Project
{
    using System;
    using System.IO;
    using System.Net.Security;
    using System.Security.Authentication;
    using System.Security.Cryptography;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Net;
    


    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== .NET 9 加密與協定展示 ===\n");

            // 1. 協定 (Protocols) & 憑證 (Certificates) 示範：建立 TLS 1.3 安全連線
            await DemonstrateTlsAndCertificateAsync();

            // 2. 演算法 (Algorithms) & 金鑰 (Keys) 示範：使用 RSA 與 AES-GCM
            DemonstrateCryptography();

            string originalMessage = "這是一段機密文字";
            string password = "MySecretPassword"; // 您的加密金鑰

            Console.WriteLine($"原始文字：{originalMessage}");

            // 加密
            string encrypted = EncryptString(originalMessage, password);
            Console.WriteLine($"加密後文字：{encrypted}");

            // 解密
            string decrypted = DecryptString(encrypted, password);
            Console.WriteLine($"解密後文字：{decrypted}");

            // 1. 金鑰管理 (RSA PEM)
            using RSA rsa = RSA.Create(2048);
            string pubKey = rsa.ExportRSAPublicKeyPem();
            string privKey = rsa.ExportPkcs8PrivateKeyPem();
            Console.WriteLine("RSA Keys generated and exported to PEM.");

            // 2. 數位簽章 (SHA-3 支援偵測)
            string data = "Hello .NET 8!";
            byte[] dataBytes = Encoding.UTF8.GetBytes(data);

            HashAlgorithmName hashAlg = SHA3_256.IsSupported ? HashAlgorithmName.SHA3_256 : HashAlgorithmName.SHA256;
            byte[] signature = rsa.SignData(dataBytes, hashAlg, RSASignaturePadding.Pkcs1);
            Console.WriteLine($"Signed using: {hashAlg.Name}");

            // 3. AES-GCM 加解密 (必須指定 Tag Size)
            byte[] key = RandomNumberGenerator.GetBytes(32);
            byte[] nonce = RandomNumberGenerator.GetBytes(12);
            byte[] tag = new byte[16];
            byte[] cipherText = new byte[dataBytes.Length];

            // .NET 8 必須明確指定 tagSizeInBytes
            using AesGcm aesGcm = new AesGcm(key, tagSizeInBytes: 16);
            aesGcm.Encrypt(nonce, dataBytes, cipherText, tag);
            Console.WriteLine("AES-GCM Encryption successful.");

            // 4. 數位憑證 (X.509)
            using X509Store store = new X509Store(StoreName.Root, StoreLocation.CurrentUser);
            store.Open(OpenFlags.ReadOnly);
            Console.WriteLine($"Certs in Store: {store.Certificates.Count}");

            // 1. 網路傳輸協定 (Protocols) 設定展示
            DemonstrateProtocolConfiguration();

            // 2. 金鑰管理 (Keys) - 產生現代 RSA 金鑰並導出原生 PEM
            Console.WriteLine("[2. 金鑰管理] 正在產生 2048-bit RSA 金鑰組...");
            using RSA rsaSender = RSA.Create(2048);
            string publicKeyPem = rsaSender.ExportRSAPublicKeyPem();
            string privateKeyPem = rsaSender.ExportPkcs8PrivateKeyPem();
            Console.WriteLine("-> 金鑰組已成功產生，並透過原生方法導出為標準 PEM 字串。\n");

            // 3. 次世代雜湊與數位簽章 (Signature & Hash)
            Console.WriteLine("[3. 數位簽章] 模擬傳送端對合約資料進行雜湊與簽章...");
            string contractText = "本合約由甲乙雙方共同簽署，金額為新台幣 1,000,000 元。";

            // 💡 平台支援檢查：若作業系統支援，則優先採用次世代標準 SHA-3，否則降級為主流的 SHA-256
            HashAlgorithmName hashAlgorithm = SHA3_256.IsSupported ? HashAlgorithmName.SHA3_256 : HashAlgorithmName.SHA256;
            Console.WriteLine($"-> [系統偵測] 優先採用 {hashAlgorithm.Name} 演算法進行雜湊與簽章。");

            // 💡 .NET 9 新寫法：展示一體化單發雜湊 (One-shot Hashing via CryptographicOperations)
            byte[] contractBytes = Encoding.UTF8.GetBytes(contractText);
            byte[] hashedBytes = CryptographicOperations.HashData(hashAlgorithm, contractBytes);
            Console.WriteLine($"-> 資料之 {hashAlgorithm.Name} 雜湊值 (Base64): {Convert.ToBase64String(hashedBytes)}");

            // 執行 RSA 數位簽章
            byte[] signatureBytes = rsaSender.SignData(contractBytes, hashAlgorithm, RSASignaturePadding.Pkcs1);
            Console.WriteLine($"-> 產生的數位簽章 (Base64):\n   {Convert.ToBase64String(signatureBytes)}");

            // 接收端：模擬載入公鑰並驗證簽章
            using RSA rsaReceiver = RSA.Create();
            rsaReceiver.ImportFromPem(publicKeyPem);
            bool isSignatureValid = rsaReceiver.VerifyData(contractBytes, signatureBytes, hashAlgorithm, RSASignaturePadding.Pkcs1);
            Console.WriteLine($"-> 接收端使用公鑰驗證簽章結果: {(isSignatureValid ? "成功 (資料完整且來源正確)" : "失敗")}\n");

            // 4. 加解密演算法 (Cryptographic Algorithms) - AES-GCM (帶驗證的對稱加密)
            Console.WriteLine("[4. 對稱加密] 處理敏感資料加解密 (使用 AES-GCM 演算法)...");
            string secretPayload = "這是不可洩漏的最高機密欄位：UserPassword123";

            // 使用現代化 API 取得 32 位元組（256-bit）加密金鑰
            byte[] aesKey = RandomNumberGenerator.GetBytes(32);

            // 執行加密
            var (ciphertext, nonce2, tag2) = EncryptAesGcm(secretPayload, aesKey);
            Console.WriteLine($"-> 加密後密文 (Base64): {Convert.ToBase64String(ciphertext)}");
            Console.WriteLine($"-> 認證標籤 Tag (Base64): {Convert.ToBase64String(tag)}");

            // 執行解密
            string decryptedPayload = DecryptAesGcm(ciphertext, aesKey, nonce, tag);
            Console.WriteLine($"-> 解密後還原本文: {decryptedPayload}\n");

            // 5. 數位憑證 (Certificates) 載入展示
            DemonstrateCertificateLoading();
        }

        /// <summary>
        /// 示範如何配置最新的 TLS 1.3 協定與驗證數位憑證
        /// </summary>
        static async Task DemonstrateTlsAndCertificateAsync()
        {
            Console.WriteLine("[1] 正在測試 協定 (TLS 1.3) 與 憑證 (Certificate)...");

            // 限制僅使用 .NET 8 推薦的 TLS 1.3 安全協定
            var sslOptions = new SslClientAuthenticationOptions
            {
                TargetHost = "://google.com",
                EnabledSslProtocols = SslProtocols.Tls13,
                RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) =>
                {
                    // 讀取並檢查伺服器憑證資訊
                    if (certificate is X509Certificate2 cert2)
                    {
                        Console.WriteLine($"   - 伺服器憑證主體: {cert2.Subject}");
                        Console.WriteLine($"   - 憑證到期日: {cert2.NotAfter}");
                    }
                    return sslPolicyErrors == SslPolicyErrors.None; // 憑證驗證結果
                }
            };

            using var client = new System.Net.Sockets.TcpClient("://google.com", 443);
            using var sslStream = new SslStream(client.GetStream(), false);

            await sslStream.AuthenticateAsClientAsync(sslOptions);
            Console.WriteLine($"   - 成功建立 {sslStream.SslProtocol} 安全加密通道。\n");
        }

        /// <summary>
        /// 示範非對稱/對稱演算法與金鑰管理
        /// </summary>
        static void DemonstrateCryptography()
        {
            Console.WriteLine("[2] 正在測試 演算法 (Algorithms) 與 金鑰 (Keys)...");
            string secretMessage = "這是一段需要被保護的機密資料。";
            byte[] plainBytes = Encoding.UTF8.GetBytes(secretMessage);

            // --- A. 非對稱演算法：RSA (用於金鑰交換或簽章) ---
            // .NET 8 建議使用 Create 獲取最佳效能與跨平台實作，金鑰長度 3072 位元符合最新安全指引
            using var rsa = RSA.Create(3072);
            Console.WriteLine($"   - 產生的 RSA 金鑰演算法: {rsa.SignatureAlgorithm}，長度: {rsa.KeySize} bits");

            // --- B. 對稱演算法：AES-GCM (用於高效能資料加密) ---
            // .NET 8 強烈建議使用具備認證加密 (AEAD) 的 AES-GCM 演算法
            byte[] aesKey = new byte[32]; // 256-bit 金鑰
            byte[] nonce = new byte[AesGcm.NonceByteSizes.MaxSize]; // 96-bit 植體
            byte[] tag = new byte[AesGcm.TagByteSizes.MaxSize]; // 128-bit 驗證標籤

            RandomNumberGenerator.Fill(aesKey); // 安全隨機產生金鑰
            RandomNumberGenerator.Fill(nonce);  // 安全隨機產生 Nonce

            using var aesGcm = new AesGcm(aesKey, tag.Length);
            byte[] ciphertext = new byte[plainBytes.Length];

            // 加密執行
            aesGcm.Encrypt(nonce, plainBytes, ciphertext, tag);
            Console.WriteLine($"   - AES-GCM 加密完成。密文長度: {ciphertext.Length} bytes");

            // 解密執行
            byte[] decryptedBytes = new byte[ciphertext.Length];
            aesGcm.Decrypt(nonce, ciphertext, tag, decryptedBytes);

            Console.WriteLine($"   - 解密後文字: {Encoding.UTF8.GetString(decryptedBytes)}\n");
        }

        public static string EncryptString(string plainText, string password)
        {
            using (Aes aes = Aes.Create())
            {
                // 使用密碼衍生函式 (PBKDF2) 產生安全的金鑰和 IV
                Rfc2898DeriveBytes key = new Rfc2898DeriveBytes(password, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x72 });
                aes.Key = key.GetBytes(32);
                aes.IV = key.GetBytes(16);

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(plainText);
                        }
                    }
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        public static string DecryptString(string cipherText, string password)
        {
            byte[] buffer = Convert.FromBase64String(cipherText);

            using (Aes aes = Aes.Create())
            {
                Rfc2898DeriveBytes key = new Rfc2898DeriveBytes(password, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x72 });
                aes.Key = key.GetBytes(32);
                aes.IV = key.GetBytes(16);

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream(buffer))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            return sr.ReadToEnd();
                        }
                    }
                }
            }
        }

        #region 密碼學與通訊協定核心函式

        // 1. 網路傳輸協定配置
        static void DemonstrateProtocolConfiguration()
        {
            Console.WriteLine("[1. 網路傳輸協定]");
            // 配置全域 HttpClient 傳輸安全協議，優先鎖定 TLS 1.3
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls13 | SecurityProtocolType.Tls12;
            Console.WriteLine($"-> 已配置全域 HttpClient 傳輸安全協議。目前設定值: {ServicePointManager.SecurityProtocol}\n");
        }

        // 4. 對稱加解密功能 (AES-GCM)
        static (byte[] ciphertext, byte[] nonce, byte[] tag) EncryptAesGcm(string plainText, byte[] key)
        {
            byte[] plaintextBytes = Encoding.UTF8.GetBytes(plainText);

            byte[] nonce = RandomNumberGenerator.GetBytes(12); // GCM 規格標準 12 位元組
            byte[] tag = new byte[16];                         // GCM 規格標準 16 位元組
            byte[] ciphertext = new byte[plaintextBytes.Length];

            // 💡 .NET 8/9 強制規範：在建構子中必須明確傳入 2 個引數指定 tagSizeInBytes：16 
            using AesGcm aesGcm = new AesGcm(key, tagSizeInBytes: 16);
            aesGcm.Encrypt(nonce, plaintextBytes, ciphertext, tag);

            return (ciphertext, nonce, tag);
        }

        static string DecryptAesGcm(byte[] ciphertext, byte[] key, byte[] nonce, byte[] tag)
        {
            byte[] decryptedBytes = new byte[ciphertext.Length];

            // 💡 .NET 8/9 強制規範：解密時同樣必須指定 tagSizeInBytes
            using AesGcm aesGcm = new AesGcm(key, tagSizeInBytes: 16);
            aesGcm.Decrypt(nonce, ciphertext, tag, decryptedBytes);

            return Encoding.UTF8.GetString(decryptedBytes);
        }

        // 5. 數位憑證管理 (X.509)
        static void DemonstrateCertificateLoading()
        {
            Console.WriteLine("[5. 數位憑證]");
            Console.WriteLine("-> 示範如何使用 .NET 9 最佳實踐 API 尋找與安全載入 X.509 憑證：");

            // 💡 情境 A：若要從檔案載入憑證，.NET 9 推薦使用全新 X509CertificateLoader（跨平台且避免過往的記憶體破壞漏洞）
            
            byte[] certData = File.ReadAllBytes("server.crt");
            using X509Certificate2 certFromFile = X509CertificateLoader.LoadCertificate(certData);
            Console.WriteLine($"-> 從檔案安全載入憑證成功，Subject: {certFromFile.Subject}");
            

            // 情境 B：從作業系統的憑證存放區讀取
            try
            {
                using X509Store store = new X509Store(StoreName.Root, StoreLocation.CurrentUser);
                store.Open(OpenFlags.ReadOnly);

                Console.WriteLine($"-> 當前系統使用者信任的根憑證數量: {store.Certificates.Count} 筆");
                if (store.Certificates.Count > 0)
                {
                    X509Certificate2 firstCert = store.Certificates[0];
                    Console.WriteLine($"-> 範例根憑證簽發者: {firstCert.Issuer}");
                }
                store.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"-> 無法讀取系統憑證存放區: {ex.Message}");
            }
            Console.WriteLine();
        }
    }
    #endregion
}

