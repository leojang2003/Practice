﻿using System;
using System.IO;
using System.Net;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace DotNet5Project
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==================================================");
            Console.WriteLine(" .NET 5 SDK 協定、憑證、金鑰與加解密全功能展示");
            Console.WriteLine("==================================================\n");

            try
            {
                // 1. 網路傳輸協定 (Protocols) 設定展示
                DemonstrateProtocolConfiguration();

                // 2. 金鑰管理 (Keys) - 產生並匯出非對稱金鑰組
                Console.WriteLine("[2. 金鑰管理] 正在產生 2048-bit RSA 金鑰組...");
                using RSA rsaSender = RSA.Create(2048);

                // 修正：.NET 5 尚未支援 ExportRSAPublicKeyPem()，改用以下自訂方法轉為標準 PEM 格式字串
                string publicKeyPem = ExportKeyToPem(rsaSender.ExportRSAPublicKey(), "RSA PUBLIC KEY");
                string privateKeyPem = ExportKeyToPem(rsaSender.ExportPkcs8PrivateKey(), "PRIVATE KEY");
                Console.WriteLine("-> 金鑰組已成功產生，並已格式化為標準 PEM 字串。\n");

                // 3. 數位簽章與雜湊演算法 (Signature & Hash)
                Console.WriteLine("[3. 數位簽章] 模擬傳送端對合約資料進行雜湊與簽章...");
                string contractText = "本合約由甲乙雙方共同簽署，金額為新台幣 1,000,000 元。";

                // 使用 SHA256 雜湊與 RSA 私鑰進行數位簽章
                byte[] signatureBytes = SignData(contractText, rsaSender);
                Console.WriteLine($"-> 產生的數位簽章 (Base64): {Convert.ToBase64String(signatureBytes)}");

                // 接收端：模擬載入公鑰並驗證簽章 (.NET 5 支援 ImportFromPem)
                using RSA rsaReceiver = RSA.Create();
                rsaReceiver.ImportFromPem(publicKeyPem);
                bool isSignatureValid = VerifyData(contractText, signatureBytes, rsaReceiver);
                Console.WriteLine($"-> 接收端使用公鑰驗證簽章結果: {(isSignatureValid ? "成功 (資料完整且來源正確)" : "失敗")}\n");

                // 4. 加解密演算法 (Cryptographic Algorithms) - AES-GCM (帶驗證的對稱加密)
                Console.WriteLine("[4. 對稱加密] 處理敏感資料加解密 (使用 .NET 5 推薦的 AES-GCM 演算法)...");
                string secretPayload = "這是不可洩漏的最高機密欄位：UserPassword123";

                // 隨機產生 256-bit 對稱金鑰 (32 位元組)
                byte[] aesKey = new byte[32];
                RandomNumberGenerator.Fill(aesKey);

                // 執行加密
                var (ciphertext, nonce, tag) = EncryptAesGcm(secretPayload, aesKey);
                Console.WriteLine($"-> 加密後密文 (Base64): {Convert.ToBase64String(ciphertext)}");
                Console.WriteLine($"-> 認證標籤 Tag (Base64): {Convert.ToBase64String(tag)}");

                // 執行解密
                string decryptedPayload = DecryptAesGcm(ciphertext, aesKey, nonce, tag);
                Console.WriteLine($"-> 解密後還原本文: {decryptedPayload}\n");

                // 5. 數位憑證 (Certificates) 載入展示
                DemonstrateCertificateLoading();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n[錯誤] 執行過程中發生異常: {ex.Message}");
            }

            Console.WriteLine("==================================================");
            Console.WriteLine(" 測試執行完畢，請按任意鍵結束...");
            Console.WriteLine("==================================================");
            Console.ReadKey();
        }

        #region 金鑰格式化工具 (用於解決 .NET 5 缺少 ExportPEM 的問題)
        /// <summary>
        /// 將二進位金鑰資料包裝成標準的 RFC 7468 PEM 格式字串
        /// </summary>
        private static string ExportKeyToPem(byte[] keyData, string label)
        {
            string base64 = Convert.ToBase64String(keyData);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"-----BEGIN {label}-----");

            // 每 64 個字元換行一次，符合標準 PEM 格式規範
            for (int i = 0; i < base64.Length; i += 64)
            {
                int length = Math.Min(64, base64.Length - i);
                sb.AppendLine(base64.Substring(i, length));
            }
            sb.AppendLine($"-----END {label}-----");
            return sb.ToString();
        }
        #endregion

        #region 1. 網路傳輸協定配置說明
        private static void DemonstrateProtocolConfiguration()
        {
            Console.WriteLine("[1. 網路傳輸協定]");

            // 在 .NET 5 中，發出全域網路請求時，可以透過以下設定強制指定安全協定
            // 系統將優先使用 TLS 1.3 (目前最安全的傳輸層協議) 與 TLS 1.2
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls13 | SecurityProtocolType.Tls12;

            Console.WriteLine($"-> 已配置全域 HttpClient 傳輸安全協議。目前設定值: {ServicePointManager.SecurityProtocol}");
            Console.WriteLine("-> (註: 若在 ASP.NET Core 5.0 Kestrel 伺服器中，則會在 ListenOptions.UseHttps 中指定 SslProtocols.Tls13)\n");
        }
        #endregion

        #region 3. 數位簽章與雜湊函式 (RSA + SHA256)
        private static byte[] SignData(string message, RSA privateKey)
        {
            byte[] dataBytes = Encoding.UTF8.GetBytes(message);
            // 內部流程：先將資料經由 SHA256 計算雜湊值(Hash)，再用 RSA 私鑰加密雜湊值完成簽章 (使用 PKCS#1 填補模式)
            return privateKey.SignData(dataBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        }

        private static bool VerifyData(string message, byte[] signature, RSA publicKey)
        {
            byte[] dataBytes = Encoding.UTF8.GetBytes(message);
            // 接收端用相同的 SHA256 算雜湊，並用公鑰解開簽章比對是否一致
            return publicKey.VerifyData(dataBytes, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        }
        #endregion

        #region 4. 對稱加解密功能 (AES-GCM)
        // AES-GCM 屬於 AEAD 演算法，加密同時會產出 Tag 用於防篡改，比傳統 CBC 模式安全
        private static (byte[] ciphertext, byte[] nonce, byte[] tag) EncryptAesGcm(string plainText, byte[] key)
        {
            byte[] plaintextBytes = Encoding.UTF8.GetBytes(plainText);

            // GCM 模式標準規範：隨機隨機數 (Nonce) 為 12 位元組
            byte[] nonce = new byte[12];
            RandomNumberGenerator.Fill(nonce);

            // 認證標籤 (Tag) 標準為 16 位元組
            byte[] tag = new byte[16];
            byte[] ciphertext = new byte[plaintextBytes.Length];

            // 建立 .NET 5 密碼學實例進行加密
            using AesGcm aesGcm = new AesGcm(key);
            aesGcm.Encrypt(nonce, plaintextBytes, ciphertext, tag);

            return (ciphertext, nonce, tag);
        }

        private static string DecryptAesGcm(byte[] ciphertext, byte[] key, byte[] nonce, byte[] tag)
        {
            byte[] decryptedBytes = new byte[ciphertext.Length];

            // 建立 .NET 5 密碼學實例進行解密驗證，若密文或 Tag 被竄改，此處會直接拋出異常
            using AesGcm aesGcm = new AesGcm(key);
            aesGcm.Decrypt(nonce, ciphertext, tag, decryptedBytes);

            return Encoding.UTF8.GetString(decryptedBytes);
        }
        #endregion

        #region 5. 數位憑證管理 (X.509)
        private static void DemonstrateCertificateLoading()
        {
            Console.WriteLine("[5. 數位憑證]");
            Console.WriteLine("-> 示範如何自檔案系統或 Windows 憑證存放區 (Certificate Store) 載入 X.509 憑證：");

            // 情境：從作業系統的信任根憑證授權單位中尋找憑證
            try
            {
                using X509Store store = new X509Store(StoreName.Root, StoreLocation.CurrentUser);
                store.Open(OpenFlags.ReadOnly);

                Console.WriteLine($"-> 當前系統使用者信任的根憑證數量: {store.Certificates.Count} 筆");
                if (store.Certificates.Count > 0)
                {
                    Console.WriteLine($"-> 範例根憑證簽發者: {store.Certificates[0].Issuer}");
                }
                store.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"-> 無法讀取系統憑證存放區 (可能受限於權限): {ex.Message}");
            }
            Console.WriteLine();
        }
        #endregion
    }
}
