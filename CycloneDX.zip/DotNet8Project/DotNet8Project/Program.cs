﻿namespace DotNet8Project
{
    using System;
    using System.IO;
    using System.Net.Security;
    using System.Security.Authentication;
    using System.Security.Cryptography;
    using System.Text;
    using System.Security.Cryptography.X509Certificates;


    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== .NET 8 加密與協定展示 ===\n");

            // 1. 協定 (Protocols) & 憑證 (Certificates) 示範：建立 TLS 1.3 安全連線
            await DemonstrateTlsAndCertificateAsync();

            // 2. 演算法 (Algorithms) & 金鑰 (Keys) 示範：使用 RSA 與 AES-GCM
            DemonstrateCryptography();

            string originalMessage = "這是一段機密文字";
            string password = "MySecretPassword"; // 您的加密金鑰

            Console.WriteLine($"原始文字：{originalMessage}");

            // 加密
            string encrypted = EncryptString(originalMessage, password);
            Console.WriteLine($"加密後文字：{encrypted}");

            // 解密
            string decrypted = DecryptString(encrypted, password);
            Console.WriteLine($"解密後文字：{decrypted}");

            // 1. 金鑰管理 (RSA PEM)
            using RSA rsa = RSA.Create(2048);
            string pubKey = rsa.ExportRSAPublicKeyPem();
            string privKey = rsa.ExportPkcs8PrivateKeyPem();
            Console.WriteLine("RSA Keys generated and exported to PEM.");

            // 2. 數位簽章 (SHA-3 支援偵測)
            string data = "Hello .NET 8!";
            byte[] dataBytes = Encoding.UTF8.GetBytes(data);

            HashAlgorithmName hashAlg = SHA3_256.IsSupported ? HashAlgorithmName.SHA3_256 : HashAlgorithmName.SHA256;
            byte[] signature = rsa.SignData(dataBytes, hashAlg, RSASignaturePadding.Pkcs1);
            Console.WriteLine($"Signed using: {hashAlg.Name}");

            // 3. AES-GCM 加解密 (必須指定 Tag Size)
            byte[] key = RandomNumberGenerator.GetBytes(32);
            byte[] nonce = RandomNumberGenerator.GetBytes(12);
            byte[] tag = new byte[16];
            byte[] cipherText = new byte[dataBytes.Length];

            // .NET 8 必須明確指定 tagSizeInBytes
            using AesGcm aesGcm = new AesGcm(key, tagSizeInBytes: 16);
            aesGcm.Encrypt(nonce, dataBytes, cipherText, tag);
            Console.WriteLine("AES-GCM Encryption successful.");

            // 4. 數位憑證 (X.509)
            using X509Store store = new X509Store(StoreName.Root, StoreLocation.CurrentUser);
            store.Open(OpenFlags.ReadOnly);
            Console.WriteLine($"Certs in Store: {store.Certificates.Count}");
        }

        /// <summary>
        /// 示範如何配置最新的 TLS 1.3 協定與驗證數位憑證
        /// </summary>
        static async Task DemonstrateTlsAndCertificateAsync()
        {
            Console.WriteLine("[1] 正在測試 協定 (TLS 1.3) 與 憑證 (Certificate)...");

            // 限制僅使用 .NET 8 推薦的 TLS 1.3 安全協定
            var sslOptions = new SslClientAuthenticationOptions
            {
                TargetHost = "://google.com",
                EnabledSslProtocols = SslProtocols.Tls13,
                RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) =>
                {
                    // 讀取並檢查伺服器憑證資訊
                    if (certificate is X509Certificate2 cert2)
                    {
                        Console.WriteLine($"   - 伺服器憑證主體: {cert2.Subject}");
                        Console.WriteLine($"   - 憑證到期日: {cert2.NotAfter}");
                    }
                    return sslPolicyErrors == SslPolicyErrors.None; // 憑證驗證結果
                }
            };

            using var client = new System.Net.Sockets.TcpClient("://google.com", 443);
            using var sslStream = new SslStream(client.GetStream(), false);

            await sslStream.AuthenticateAsClientAsync(sslOptions);
            Console.WriteLine($"   - 成功建立 {sslStream.SslProtocol} 安全加密通道。\n");
        }

        /// <summary>
        /// 示範非對稱/對稱演算法與金鑰管理
        /// </summary>
        static void DemonstrateCryptography()
        {
            Console.WriteLine("[2] 正在測試 演算法 (Algorithms) 與 金鑰 (Keys)...");
            string secretMessage = "這是一段需要被保護的機密資料。";
            byte[] plainBytes = Encoding.UTF8.GetBytes(secretMessage);

            // --- A. 非對稱演算法：RSA (用於金鑰交換或簽章) ---
            // .NET 8 建議使用 Create 獲取最佳效能與跨平台實作，金鑰長度 3072 位元符合最新安全指引
            using var rsa = RSA.Create(3072);
            Console.WriteLine($"   - 產生的 RSA 金鑰演算法: {rsa.SignatureAlgorithm}，長度: {rsa.KeySize} bits");

            // --- B. 對稱演算法：AES-GCM (用於高效能資料加密) ---
            // .NET 8 強烈建議使用具備認證加密 (AEAD) 的 AES-GCM 演算法
            byte[] aesKey = new byte[32]; // 256-bit 金鑰
            byte[] nonce = new byte[AesGcm.NonceByteSizes.MaxSize]; // 96-bit 植體
            byte[] tag = new byte[AesGcm.TagByteSizes.MaxSize]; // 128-bit 驗證標籤

            RandomNumberGenerator.Fill(aesKey); // 安全隨機產生金鑰
            RandomNumberGenerator.Fill(nonce);  // 安全隨機產生 Nonce

            using var aesGcm = new AesGcm(aesKey, tag.Length);
            byte[] ciphertext = new byte[plainBytes.Length];

            // 加密執行
            aesGcm.Encrypt(nonce, plainBytes, ciphertext, tag);
            Console.WriteLine($"   - AES-GCM 加密完成。密文長度: {ciphertext.Length} bytes");

            // 解密執行
            byte[] decryptedBytes = new byte[ciphertext.Length];
            aesGcm.Decrypt(nonce, ciphertext, tag, decryptedBytes);

            Console.WriteLine($"   - 解密後文字: {Encoding.UTF8.GetString(decryptedBytes)}\n");
        }

        public static string EncryptString(string plainText, string password)
        {
            using (Aes aes = Aes.Create())
            {
                // 使用密碼衍生函式 (PBKDF2) 產生安全的金鑰和 IV
                Rfc2898DeriveBytes key = new Rfc2898DeriveBytes(password, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x72 });
                aes.Key = key.GetBytes(32);
                aes.IV = key.GetBytes(16);

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(plainText);
                        }
                    }
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        public static string DecryptString(string cipherText, string password)
        {
            byte[] buffer = Convert.FromBase64String(cipherText);

            using (Aes aes = Aes.Create())
            {
                Rfc2898DeriveBytes key = new Rfc2898DeriveBytes(password, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x72 });
                aes.Key = key.GetBytes(32);
                aes.IV = key.GetBytes(16);

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream(buffer))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            return sr.ReadToEnd();
                        }
                    }
                }
            }
        }
    }
}
