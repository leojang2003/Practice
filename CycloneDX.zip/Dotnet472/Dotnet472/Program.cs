﻿namespace Dotnet472
{
    using System;
    using System.IO;
    using System.Net;
    using System.Net.Security;
    using System.Security.Authentication;
    using System.Security.Cryptography;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;

    namespace NetFrameworkCryptoDemo
    {
        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("=== .NET Framework 4.7 加密與協定展示 ===\n");

                // 1. 協定 (Protocols) & 憑證 (Certificates) 示範
                DemonstrateTlsAndCertificate();

                // 2. 演算法 (Algorithms) & 金鑰 (Keys) 示範
                DemonstrateCryptography();

                Console.WriteLine("測試結束，請按任意鍵退出...");
                Console.ReadKey();
            }

            /// <summary>
            /// 示範如何配置安全傳輸協定與驗證數位憑證
            /// </summary>
            static void DemonstrateTlsAndCertificate()
            {
                Console.WriteLine("[1] 正在測試 協定 (Protocols) 與 憑證 (Certificates)...");

                // 在 .NET Framework 中，必須顯式啟用安全協定。
                // .NET 4.7 支援 TLS 1.2。若底層作業系統(如 Windows 11/Server 2022)支援且環境允許，亦可透過型轉加入 TLS 1.3 ((SecurityProtocolType)12288)
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                Console.WriteLine($"   - 已設定 ServicePointManager.SecurityProtocol: {ServicePointManager.SecurityProtocol}");

                // 設定憑證驗證回呼 (用於盤點憑證資產)
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) =>
                {
                    if (certificate != null)
                    {
                        // 轉換為 X509Certificate2 以讀取詳細憑證資訊
                        X509Certificate2 cert2 = new X509Certificate2(certificate);
                        Console.WriteLine($"   - 檢測到伺服器憑證主體: {cert2.Subject}");
                        Console.WriteLine($"   - 憑證到期日: {cert2.NotAfter}");
                        Console.WriteLine($"   - 憑證雜湊演算法: {cert2.SignatureAlgorithm.FriendlyName}");
                    }
                    return sslPolicyErrors == SslPolicyErrors.None; // 僅接受合法的憑證
                };

                try
                {
                    // 發送 HTTPS 請求觸發 TLS 握手與憑證交換
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://google.com");
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        Console.WriteLine($"   - 成功透過安全通道連線，回應狀態: {response.StatusCode}\n");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"   - 連線失敗: {ex.Message}\n");
                }
            }

            /// <summary>
            /// 示範非對稱/對稱演算法與金鑰管理
            /// </summary>
            static void DemonstrateCryptography()
            {
                Console.WriteLine("[2] 正在測試 演算法 (Algorithms) 與 金鑰 (Keys)...");
                string secretMessage = "這是 .NET Framework 4.7 的機密資料。";

                // --- A. 非對稱演算法：RSA (指定 3072-bit 安全金鑰長度) ---
                // 在 .NET Framework 中，建議使用 RSACng 或 RSACryptoServiceProvider
                using (RSACng rsa = new RSACng(3072))
                {
                    Console.WriteLine($"   - 產生的 RSA 演算法: {rsa.KeyExchangeAlgorithm}，金鑰長度: {rsa.KeySize} bits");

                    // 匯出公開金鑰資訊 (可用於 CBOM 記錄金鑰資產)
                    RSAParameters publicKeys = rsa.ExportParameters(false);
                    Console.WriteLine($"   - 公開金鑰模數(Modulus)長度: {publicKeys.Modulus.Length} bytes");
                }

                // --- B. 對稱演算法：AES-CBC (256-bit 金鑰) ---
                // 備註：.NET Framework 4.7 原生不支援 AesGcm，必須使用傳統的 AesCryptoServiceProvider 搭配 CBC 模式
                using (AesCryptoServiceProvider aes = new AesCryptoServiceProvider())
                {
                    aes.KeySize = 256;             // 256-bit 金鑰
                    aes.BlockSize = 128;           // 128-bit 區塊大小
                    aes.Mode = CipherMode.CBC;     // CBC 密碼工作模式
                    aes.Padding = PaddingMode.PKCS7; // 填補模式

                    // 自動安全隨機產生金鑰與初始向量 (IV)
                    aes.GenerateKey();
                    aes.GenerateIV();

                    Console.WriteLine($"   - 產生的對稱演算法: AES (Mode: {aes.Mode})");
                    Console.WriteLine($"   - 金鑰長度: {aes.KeySize} bits，IV 長度: {aes.IV.Length * 8} bits");

                    // 執行加密
                    byte[] cipherBytes;
                    ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                    using (MemoryStream msEncrypt = new MemoryStream())
                    {
                        using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                            {
                                swEncrypt.Write(secretMessage);
                            }
                            cipherBytes = msEncrypt.ToArray();
                        }
                    }
                    Console.WriteLine($"   - AES 加密完成，密文長度: {cipherBytes.Length} bytes\n");
                }
            }
        }
    }
}
