﻿using System;
using System.Net;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

Console.WriteLine("==================================================");
Console.WriteLine(" .NET 7 SDK 協定、憑證、金鑰與加解密全功能展示");
Console.WriteLine("==================================================\n");

try
{
    // 1. 網路傳輸協定 (Protocols) 設定展示
    DemonstrateProtocolConfiguration();

    // 2. 金鑰管理 (Keys) - 產生現代 RSA 金鑰
    Console.WriteLine("[2. 金鑰管理] 正在產生 2048-bit RSA 金鑰組...");
    using RSA rsaSender = RSA.Create(2048);
    // .NET 7 原生支援直接導出 PEM 格式字串
    string publicKeyPem = rsaSender.ExportRSAPublicKeyPem();
    string privateKeyPem = rsaSender.ExportPkcs8PrivateKeyPem();
    Console.WriteLine("-> 金鑰組已成功產生，並透過原生方法導出為標準 PEM 字串。\n");

    // 3. 數位簽章與雜湊演算法 (Signature & Hash)
    Console.WriteLine("[3. 數位簽章] 模擬傳送端對合約資料進行雜湊與簽章...");
    string contractText = "本合約由甲乙雙方共同簽署，金額為新台幣 1,000,000 元。";

    // 使用 .NET 7 內建的工業安全標準 SHA256 進行雜湊與 RSA 私鑰簽章
    byte[] signatureBytes = SignData(contractText, rsaSender);
    Console.WriteLine($"-> 產生的數位簽章 (SHA256 + RSA, Base64):\n   {Convert.ToBase64String(signatureBytes)}");

    // 接收端：模擬載入公鑰並驗證簽章
    using RSA rsaReceiver = RSA.Create();
    rsaReceiver.ImportFromPem(publicKeyPem);
    bool isSignatureValid = VerifyData(contractText, signatureBytes, rsaReceiver);
    Console.WriteLine($"-> 接收端使用公鑰驗證簽章結果: {(isSignatureValid ? "成功 (資料完整且來源正確)" : "失敗")}\n");

    // 4. 加解密演算法 (Cryptographic Algorithms) - AES-GCM (帶驗證的對稱加密)
    Console.WriteLine("[4. 對稱加密] 處理敏感資料加解密 (使用 AES-GCM 演算法)...");
    string secretPayload = "這是不可洩漏的最高機密欄位：UserPassword123";

    // 安全且快速地取得 32 位元組（256-bit）加密金鑰
    byte[] aesKey = RandomNumberGenerator.GetBytes(32);

    // 執行加密
    var (ciphertext, nonce, tag) = EncryptAesGcm(secretPayload, aesKey);
    Console.WriteLine($"-> 加密後密文 (Base64): {Convert.ToBase64String(ciphertext)}");
    Console.WriteLine($"-> 認證標籤 Tag (Base64): {Convert.ToBase64String(tag)}");

    // 執行解密
    string decryptedPayload = DecryptAesGcm(ciphertext, aesKey, nonce, tag);
    Console.WriteLine($"-> 解密後還原本文: {decryptedPayload}\n");

    // 5. 數位憑證 (Certificates) 載入展示
    DemonstrateCertificateLoading();
}
catch (Exception ex)
{
    Console.WriteLine($"\n[錯誤] 執行過程中發生異常: {ex.Message}");
}

Console.WriteLine("==================================================");
Console.WriteLine(" 測試執行完畢，請按任意鍵結束...");
Console.WriteLine("==================================================");
Console.ReadKey();


#region 密碼學與通訊協定核心函式

// 1. 網路傳輸協定配置
void DemonstrateProtocolConfiguration()
{
    Console.WriteLine("[1. 網路傳輸協定]");
    // 配置全域 HttpClient 傳輸安全協議，優先鎖定 TLS 1.3
    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls13 | SecurityProtocolType.Tls12;
    Console.WriteLine($"-> 已配置全域 HttpClient 傳輸安全協議。目前設定值: {ServicePointManager.SecurityProtocol}\n");
}

// 3. 數位簽章與雜湊函式 (RSA + SHA256)
byte[] SignData(string message, RSA privateKey)
{
    byte[] dataBytes = Encoding.UTF8.GetBytes(message);
    return privateKey.SignData(dataBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
}

bool VerifyData(string message, byte[] signature, RSA publicKey)
{
    byte[] dataBytes = Encoding.UTF8.GetBytes(message);
    return publicKey.VerifyData(dataBytes, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
}

// 4. 對稱加解密功能 (AES-GCM)
(byte[] ciphertext, byte[] nonce, byte[] tag) EncryptAesGcm(string plainText, byte[] key)
{
    byte[] plaintextBytes = Encoding.UTF8.GetBytes(plainText);

    byte[] nonce = RandomNumberGenerator.GetBytes(12); // GCM 規格標準 12 位元組
    byte[] tag = new byte[16];                         // GCM 規格標準 16 位元組
    byte[] ciphertext = new byte[plaintextBytes.Length];

    // 【修正】.NET 7 的 AesGcm 建構函式僅接受 1 個引數 (key)
    // 其認證標籤的長度是由傳入 Encrypt 方法的 tag 陣列長度 (此處為 16) 來決定
    using AesGcm aesGcm = new AesGcm(key);
    aesGcm.Encrypt(nonce, plaintextBytes, ciphertext, tag);

    return (ciphertext, nonce, tag);
}

string DecryptAesGcm(byte[] ciphertext, byte[] key, byte[] nonce, byte[] tag)
{
    byte[] decryptedBytes = new byte[ciphertext.Length];

    // 【修正】.NET 7 的 AesGcm 建構函式僅接受 1 個引數 (key)
    using AesGcm aesGcm = new AesGcm(key);
    aesGcm.Decrypt(nonce, ciphertext, tag, decryptedBytes);

    return Encoding.UTF8.GetString(decryptedBytes);
}

// 5. 數位憑證管理 (X.509)
void DemonstrateCertificateLoading()
{
    Console.WriteLine("[5. 數位憑證]");
    Console.WriteLine("-> 示範如何從跨平台憑證存放區尋找與載入 X.509 憑證：");

    try
    {
        using X509Store store = new X509Store(StoreName.Root, StoreLocation.CurrentUser);
        store.Open(OpenFlags.ReadOnly);

        Console.WriteLine($"-> 當前系統使用者信任的根憑證數量: {store.Certificates.Count} 筆");
        if (store.Certificates.Count > 0)
        {
            // 【修正】store.Certificates 是集合，在 .NET 7 中必須透過索引器 [0] 
            // 取得單一 X509Certificate2 物件實例後，才能正確存取 Issuer 屬性
            X509Certificate2 firstCert = store.Certificates[0];
            Console.WriteLine($"-> 範例根憑證簽發者: {firstCert.Issuer}");
        }
        store.Close();
    }
    catch (Exception ex)
    {
        Console.WriteLine($"-> 無法讀取系統憑證存放區: {ex.Message}");
    }
    Console.WriteLine();
}

#endregion
