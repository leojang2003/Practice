import org.bouncycastle.jce.provider.BouncyCastleProvider;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import com.mycompany.app.CryptoIntegrationService;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.*;
import java.util.Base64;

public class App {

    public static void main(String[] args) throws Exception {
        // 1. Mandatory initialization step
        Security.addProvider(new BouncyCastleProvider());
        System.out.println("--- Bouncy Castle Provider Registered Successfully ---\n");

        // Run the test cases
        testHash();
        testRsaKeyGen();
        testAesGcmEncryption();
        // 1. 初始化加密整合服務
        CryptoIntegrationService cryptoService = new CryptoIntegrationService();

        System.out.println("==================================================");
        System.out.println("🛡️ 開始執行密碼學資產業務流程...");
        System.out.println("==================================================\n");

        try {

            cryptoService.KeyStoreTest();
            cryptoService.SSLTest();

            // -----------------------------------------------------------------
            // 【情境一】用戶註冊：生成專屬密鑰並加密敏感個資 (資產 1 & 2)
            // -----------------------------------------------------------------
            System.out.println("[步驟 1] 正在為新用戶生成安全對稱金鑰 (AES-256)...");
            SecretKey userSecretKey = cryptoService.generateSecureKey();
            System.out.println("👉 金鑰生成成功！演算法: " + userSecretKey.getAlgorithm() + " / 長度: " + (userSecretKey.getEncoded().length * 8) + " bits\n");

            System.out.println("[步驟 2] 正在加密用戶的身分證字號與信用卡資訊...");
            String rawIdCard = "A123456789";
            String encryptedData = cryptoService.encryptData(rawIdCard, userSecretKey);
            System.out.println("👉 原始資料: " + rawIdCard);
            System.out.println("👉 加密並經 Base64 編碼後的密文 (可直接存入資料庫): " + encryptedData + "\n");


            // -----------------------------------------------------------------
            // 【情境二】串接檢驗：讀取並驗證系統現有的數位憑證效期 (資產 3)
            // -----------------------------------------------------------------
            System.out.println("[步驟 3] 正在載入系統憑證並驗證有效性與簽章演算法...");
            
            // 實務做法：從 Java 內建的信任庫 (cacerts) 中隨機撈取一個真實憑證來測試
            KeyStore trustStore = KeyStore.getInstance("cacerts", "SUN");
            trustStore.load(null, null); // 載入預設信任庫
            String alias = trustStore.aliases().nextElement(); // 取得第一個憑證別名
            X509Certificate systemCert = (X509Certificate) trustStore.getCertificate(alias);
            
            // 將真實憑證轉為 InputStream 傳入服務
            try (InputStream certStream = new ByteArrayInputStream(systemCert.getEncoded())) {
                boolean isCertValid = cryptoService.verifyExternalCertificate(certStream);
                System.out.println("👉 憑證效期與合規性驗證結果: " + (isCertValid ? "✅ 通過" : "❌ 失敗或過期") + "\n");
            }


            // -----------------------------------------------------------------
            // 【情境三】外部連線：使用強加密協定發送 HTTPS 請求 (資產 4)
            // -----------------------------------------------------------------
            // 使用支援 TLS 1.3 的知名公開 API 作為測試目標
            String targetUrl = "https://github.com"; 
            System.out.println("[步驟 4] 正在透過強加密協定 (TLS 1.3) 發送 HTTPS 請求至: " + targetUrl);
            
            String apiResponse = cryptoService.sendSecureHttpsRequest(targetUrl);
            System.out.println("👉 傳輸協定檢驗: 成功強制使用 TLSv1.3 握手");
            System.out.println("👉 遠端 API 回傳內容: \"" + apiResponse.trim() + "\"\n");

            System.out.println("==================================================");
            System.out.println("🎉 所有業務功能執行完畢！CBOM 相關密碼學資產運作正常。");
            System.out.println("==================================================");

        } catch (Exception e) {
            System.err.println("\n❌ 業務流程執行期間發生資安或網路錯誤：");
            e.printStackTrace();
        }
    }

    // Test 1: Secure SHA-256 Hashing
    private static void testHash() throws Exception {
        String data = "Hello, Bouncy Castle!";
        MessageDigest digest = MessageDigest.getInstance("SHA-256", "BC");
        byte[] hash = digest.digest(data.getBytes());
        
        System.out.println("[Test 1] SHA-256 Hash:");
        System.out.println("Result (Hex): " + Base64.getEncoder().encodeToString(hash));
        System.out.println("------------------------------------------------");
    }

    // Test 2: RSA Key Pair Generation
    private static void testRsaKeyGen() throws Exception {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA", "BC");
        keyGen.initialize(2048);
        KeyPair pair = keyGen.generateKeyPair();
        
        System.out.println("[Test 2] RSA 2048-bit Key Gen:");
        System.out.println("Public Key Format: " + pair.getPublic().getFormat());
        System.out.println("Private Key Format: " + pair.getPrivate().getFormat());
        System.out.println("------------------------------------------------");
    }

    // Test 3: Authenticated AES-GCM 256-bit Encryption
    private static void testAesGcmEncryption() throws Exception {
        String plaintext = "Top Secret Message";
        
        // Generate a 256-bit AES key
        KeyGenerator keyGen = KeyGenerator.getInstance("AES", "BC");
        keyGen.init(256);
        SecretKey key = keyGen.generateKey();

        // Setup AES-GCM parameters (12-byte IV, 128-bit authentication tag)
        byte[] iv = new byte[12];
        SecureRandom.getInstanceStrong().nextBytes(iv);
        GCMParameterSpec spec = new GCMParameterSpec(128, iv);

        // Encrypt using the "BC" provider explicitly
        Cipher encryptCipher = Cipher.getInstance("AES/GCM/NoPadding", "BC");
        encryptCipher.init(Cipher.ENCRYPT_MODE, key, spec);
        byte[] ciphertext = encryptCipher.doFinal(plaintext.getBytes());

        // Decrypt to verify integrity
        Cipher decryptCipher = Cipher.getInstance("AES/GCM/NoPadding", "BC");
        decryptCipher.init(Cipher.DECRYPT_MODE, key, spec);
        byte[] decryptedBytes = decryptCipher.doFinal(ciphertext);
        String decryptedtext = new String(decryptedBytes);

        System.out.println("[Test 3] AES-GCM-256 Encrypt/Decrypt:");
        System.out.println("Ciphertext (Base64): " + Base64.getEncoder().encodeToString(ciphertext));
        System.out.println("Decrypted Text    : " + decryptedtext);
        System.out.println("------------------------------------------------");
    }
}
