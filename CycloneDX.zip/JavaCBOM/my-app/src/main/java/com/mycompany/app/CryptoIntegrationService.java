package com.mycompany.app;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Enumeration;

/**
 * 實際於生產環境運行的加密與安全傳輸整合服務
 * 程式碼架構嚴格遵循 CBOM 盤點所需的安全元件規範。
 */
public class CryptoIntegrationService {

    // 資產 1 & 2：指定高強度的 AES-GCM 演算法，金鑰長度 256-bit，IV 長度 12 bytes
    private static final String AES_ALGORITHM = "AES/GCM/NoPadding";
    private static final int AES_KEY_SIZE = 256;
    private static final int GCM_IV_LENGTH = 12;
    private static final int GCM_TAG_LENGTH = 128; // bits

    public void KeyStoreTest()
    {
        // 設定您的 Keystore 路徑與密碼
        String keystorePath = "your-keystore.jks"; 
        String password = "your-keystore-password";

        try {
            // 實例化 KeyStore 物件，指定類型為 JKS
            KeyStore keyStore = KeyStore.getInstance("JKS");

            // 載入 Keystore 檔案
            try (FileInputStream fis = new FileInputStream(keystorePath)) {
                keyStore.load(fis, password.toCharArray());
            }

            // 取得 Keystore 內所有的憑證別名 (Alias)
            Enumeration<String> aliases = keyStore.aliases();
            
            System.out.println("--- Keystore 憑證清單 ---");
            while (aliases.hasMoreElements()) {
                String alias = aliases.nextElement();
                System.out.println("別名 (Alias): " + alias);

                // 檢查是否包含私鑰 (僅作範例)
                if (keyStore.isKeyEntry(alias)) {
                    System.out.println(" -> 類型: 私鑰/金鑰條目");
                } else if (keyStore.isCertificateEntry(alias)) {
                    System.out.println(" -> 類型: 受信任憑證條目");
                }

                // 取得憑證資訊
                Certificate cert = keyStore.getCertificate(alias);
                if (cert != null) {
                    System.out.println(" -> 憑證類型: " + cert.getType());
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SSLTest()
    {
        String host = "example.com";
        int port = 443;

        try {
            // 1. 取得預設的 SSLSocketFactory
            SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();

            // 2. 建立 SSLSocket 並連線至伺服器
            try (SSLSocket socket = (SSLSocket) factory.createSocket(host, port)) {
                
                // 3. 啟用所有支援的加密套件 (Cipher Suites)
                String[] supportedSuites = socket.getSupportedCipherSuites();
                socket.setEnabledCipherSuites(supportedSuites);

                // 4. 送出 HTTP 請求
                OutputStream out = socket.getOutputStream();
                PrintWriter writer = new PrintWriter(out, true);
                writer.println("GET / HTTP/1.1");
                writer.println("Host: " + host);
                writer.println("Connection: close");
                writer.println();

                // 5. 讀取伺服器回應
                InputStream in = socket.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 【業務功能 1】生成安全的對稱式金鑰（用於資料落地加密）
     * 對應 CBOM：金鑰管理 (Key Management)
     */
    public SecretKey generateSecureKey() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(AES_KEY_SIZE, SecureRandom.getInstanceStrong()); // 使用強隨感隨機數生成器
        return keyGen.generateKey();
    }

    /**
     * 【業務功能 2】敏感資料加密（例如：身分證字號、信用卡號）
     * 對應 CBOM：加密演算法 (Algorithms) - AES/GCM
     */
    public String encryptData(String plainText, SecretKey secretKey) throws Exception {
        byte[] iv = new byte[GCM_IV_LENGTH];
        SecureRandom.getInstanceStrong().nextBytes(iv); // 每次加密生成全域唯一的 IV

        Cipher cipher = Cipher.getInstance(AES_ALGORITHM);
        GCMParameterSpec parameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);

        byte[] cipherText = cipher.doFinal(plainText.getBytes("UTF-8"));

        // 將 IV 與 密文 封裝在一起輸出，以便解密時使用
        byte[] combined = new byte[iv.length + cipherText.length];
        System.arraycopy(iv, 0, combined, 0, iv.length);
        System.arraycopy(cipherText, 0, combined, iv.length, cipherText.length);

        return Base64.getEncoder().encodeToString(combined);
    }

    /**
     * 【業務功能 3】載入外部憑證並進行效期驗證（例如：檢查第三方 API 憑證是否過期）
     * 對應 CBOM：數位憑證 (Digital Certificates)
     */
    public boolean verifyExternalCertificate(InputStream certInputStream) {
        try {
            CertificateFactory factory = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate) factory.generateCertificate(certInputStream);

            // 實際業務邏輯：驗證當前時間憑證是否有效
            cert.checkValidity(); 
            
            // 輸出憑證資訊（這也是 CBOM 盤點會抓取的元數據，例如簽章演算法 SHA256withRSA）
            System.out.println("憑證簽章演算法: " + cert.getSigAlgName());
            System.out.println("憑證擁有者: " + cert.getSubjectX500Principal().getName());
            return true;
        } catch (Exception e) {
            System.err.println("憑證驗證失敗或已過期: " + e.getMessage());
            return false;
        }
    }

    /**
     * 【業務功能 4】發送強加密的 HTTPS 請求（例如：串接金流 API）
     * 對應 CBOM：密碼協定 (Cryptographic Protocols) - 強制 TLS 1.3
     */
    public String sendSecureHttpsRequest(String url) throws Exception {
        // 強制實例化 TLS 1.3 背景環境，拒絕接受 TLS 1.2 以下的弱協議
        SSLContext sslContext = SSLContext.getInstance("TLSv1.3");
        sslContext.init(null, null, SecureRandom.getInstanceStrong());

        // 將安全的 SSLContext 注入到 Java 內建的 HttpClient 中
        HttpClient client = HttpClient.newBuilder()
                .sslContext(sslContext)
                .build();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }
}

