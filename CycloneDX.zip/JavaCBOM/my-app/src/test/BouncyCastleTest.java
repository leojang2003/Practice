import org.bouncycastle.jce.provider.BouncyCastleProvider;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.security.*;
import java.util.Base64;

public class BouncyCastleTest {

    public static void main(String[] args) throws Exception {
        // 1. Mandatory initialization step
        Security.addProvider(new BouncyCastleProvider());
        System.out.println("--- Bouncy Castle Provider Registered Successfully ---\n");

        // Run the test cases
        testHash();
        testRsaKeyGen();
        testAesGcmEncryption();
    }

    // Test 1: Secure SHA-256 Hashing
    private static void testHash() throws Exception {
        String data = "Hello, Bouncy Castle!";
        MessageDigest digest = MessageDigest.getInstance("SHA-256", "BC");
        byte[] hash = digest.digest(data.getBytes());
        
        System.out.println("[Test 1] SHA-256 Hash:");
        System.out.println("Result (Hex): " + Base64.getEncoder().encodeToString(hash));
        System.out.println("------------------------------------------------");
    }

    // Test 2: RSA Key Pair Generation
    private static void testRsaKeyGen() throws Exception {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA", "BC");
        keyGen.initialize(2048);
        KeyPair pair = keyGen.generateKeyPair();
        
        System.out.println("[Test 2] RSA 2048-bit Key Gen:");
        System.out.println("Public Key Format: " + pair.getPublic().getFormat());
        System.out.println("Private Key Format: " + pair.getPrivate().getFormat());
        System.out.println("------------------------------------------------");
    }

    // Test 3: Authenticated AES-GCM 256-bit Encryption
    private static void testAesGcmEncryption() throws Exception {
        String plaintext = "Top Secret Message";
        
        // Generate a 256-bit AES key
        KeyGenerator keyGen = KeyGenerator.getInstance("AES", "BC");
        keyGen.init(256);
        SecretKey key = keyGen.generateKey();

        // Setup AES-GCM parameters (12-byte IV, 128-bit authentication tag)
        byte[] iv = new byte[12];
        SecureRandom.getInstanceStrong().nextBytes(iv);
        GCMParameterSpec spec = new GCMParameterSpec(128, iv);

        // Encrypt using the "BC" provider explicitly
        Cipher encryptCipher = Cipher.getInstance("AES/GCM/NoPadding", "BC");
        encryptCipher.init(Cipher.ENCRYPT_MODE, key, spec);
        byte[] ciphertext = encryptCipher.doFinal(plaintext.getBytes());

        // Decrypt to verify integrity
        Cipher decryptCipher = Cipher.getInstance("AES/GCM/NoPadding", "BC");
        decryptCipher.init(Cipher.DECRYPT_MODE, key, spec);
        byte[] decryptedBytes = decryptCipher.doFinal(ciphertext);
        String decryptedtext = new String(decryptedBytes);

        System.out.println("[Test 3] AES-GCM-256 Encrypt/Decrypt:");
        System.out.println("Ciphertext (Base64): " + Base64.getEncoder().encodeToString(ciphertext));
        System.out.println("Decrypted Text    : " + decryptedtext);
        System.out.println("------------------------------------------------");
    }
}
