﻿using System;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DotNetCore
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== .NET Core 3.1 加密與協定展示 ===\n");

            // 1. 協定 (Protocols) & 憑證 (Certificates) 示範：配置 TLS 1.3/1.2 安全連線
            await DemonstrateTlsAndCertificateAsync();

            // 2. 演算法 (Algorithms) & 金鑰 (Keys) 示範：使用 RSA 與 AesGcm
            DemonstrateCryptography();
        }

        /// <summary>
        /// 示範如何在 .NET Core 3.1 下配置安全傳輸協定與讀取數位憑證
        /// </summary>
        static async Task DemonstrateTlsAndCertificateAsync()
        {
            Console.WriteLine(" 正在測試 協定 (Protocols) 與 憑證 (Certificates)...");

            // 在 .NET Core 3.1 中，可以同時指定 Tls13 與 Tls12，讓系統自動協商最高安全版本
            // 備註：TLS 1.3 的支援仍取決於底層作業系統 (如 Windows 10 1903+ / Linux OpenSSL 1.1.1+)
            var sslOptions = new SslClientAuthenticationOptions
            {
                TargetHost = "://google.com",
                EnabledSslProtocols = SslProtocols.Tls13 | SslProtocols.Tls12,
                RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) =>
                {
                    // 盤點並檢查伺服器憑證資訊
                    if (certificate is X509Certificate2 cert2)
                    {
                        Console.WriteLine($"   - 伺服器憑證主體: {cert2.Subject}");
                        Console.WriteLine($"   - 憑證到期日: {cert2.NotAfter}");
                        Console.WriteLine($"   - 憑證金鑰演算法: {cert2.GetKeyAlgorithm()}");
                    }
                    return sslPolicyErrors == SslPolicyErrors.None;
                }
            };

            using (var client = new System.Net.Sockets.TcpClient("://google.com", 443))
            using (var sslStream = new SslStream(client.GetStream(), false))
            {
                // .NET Core 3.1 的異步方法命名與舊版相同，與 .NET 8 效能略有差異
                await sslStream.AuthenticateAsClientAsync(sslOptions);
                Console.WriteLine($"   - 成功建立 {sslStream.SslProtocol} 安全加密通道。\n");
            }
        }

        /// <summary>
        /// 示範非對稱/對稱演算法與金鑰管理
        /// </summary>
        static void DemonstrateCryptography()
        {
            Console.WriteLine(" 正在測試 演算法 (Algorithms) 與 金鑰 (Keys)...");
            string secretMessage = "這是來自 .NET Core 3.1 的極機密字串。";
            byte[] plainBytes = Encoding.UTF8.GetBytes(secretMessage);

            // --- A. 非對稱演算法：RSA (3072-bit 安全金鑰長度) ---
            // .NET Core 3.1 支援使用 RSA.Create(int) 跨平台直接指定位元長度產生安全金鑰
            using (RSA rsa = RSA.Create(3072))
            {
                Console.WriteLine($"   - 產生的 RSA 演算法: {rsa.KeyExchangeAlgorithm}，金鑰長度: {rsa.KeySize} bits");

                // 匯出 PKCS#8 格式金鑰（CBOM 識別此類導出行為可能判定為金鑰備份/傳輸風險）
                byte[] rsaPrivateKey = rsa.ExportPkcs8PrivateKey();
                Console.WriteLine($"   - 私密金鑰已安全衍生，長度: {rsaPrivateKey.Length} bytes");
            }

            // --- B. 對稱演算法：AesGcm (具備認證加密的演算法) ---
            // .NET Core 3.1 開始正式引進內建的 AesGcm 類別，大幅提升安全性
            byte[] aesKey = new byte[32]; // 256-bit 金鑰
            byte[] nonce = new byte[12];  // 96-bit 植體 (AesGcm.NonceByteSizes 標準長度)
            byte[] tag = new byte[16];    // 128-bit 驗證標籤 (AesGcm.TagByteSizes 標準長度)

            // 安全隨機填充金鑰與 Nonce
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(aesKey);
                rng.GetBytes(nonce);
            }

            using (var aesGcm = new AesGcm(aesKey))
            {
                byte[] ciphertext = new byte[plainBytes.Length];

                // 執行加密
                aesGcm.Encrypt(nonce, plainBytes, ciphertext, tag);
                Console.WriteLine($"   - 產生的對稱演算法: AES-GCM (內建 AEAD 認證)");
                Console.WriteLine($"   - 金鑰長度: {aesKey.Length * 8} bits，密文長度: {ciphertext.Length} bytes");

                // 執行解密
                byte[] decryptedBytes = new byte[ciphertext.Length];
                aesGcm.Decrypt(nonce, ciphertext, tag, decryptedBytes);
                Console.WriteLine($"   - 解密後文字: {Encoding.UTF8.GetString(decryptedBytes)}\n");
            }
        }
    }
}
